#ques 1
import pandas as pd
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
# Load the dataset
df = pd.read_csv("AusOpen-men-2013.csv")
rounds = df['Round'].unique()
net_points_rounds = {}
for r in rounds:
    net_points_rounds[r] = df.loc[df['Round'] == r]['NPW.1']
df.boxplot(column=['NPW.1', 'NPW.2'], by='Round', figsize=(10, 6))
plt.title("Distribution of Net Points Won by Round")
plt.xlabel("Round")
plt.ylabel("Net Points Won")
plt.show()
earlier_rounds = ['R128', 'R64', 'R32']
later_rounds = ['R16', 'QF', 'SF', 'F']
df['Round_type'] = df['Round'].apply(lambda x: 'Early' if x in earlier_rounds else 'Later')
df['NPW'] = df[['NPW.1', 'NPW.2']].mean(axis=1)
df.boxplot(column=['NPW'], by='Round_type', figsize=(10, 6))
plt.title("Distribution of Net Points Won in Early vs. Later Rounds")
plt.xlabel("Round Type")
plt.ylabel("Net Points Won")
plt.show()
data["NetPts.1"] = data["NPW.1"] - data["NPA.1"]
data["NetPts.2"] = data["NPW.2"] - data["NPA.2"]
mean_net_points = data.groupby("Round")[["NetPts.1", "NetPts.2"]].mean().reset_index()
sns.boxplot(x="Round", y="NetPts.1", data=data)
sns.boxplot(x="Round", y="NetPts.2", data=data)
fig, ax = plt.subplots(figsize=(10, 6))
ax.boxplot(net_points_rounds.values(), labels=net_points_rounds.keys())
ax.set_title('Distribution of Net Points Won by Round')
ax.set_xlabel('Round')
ax.set_ylabel('Net Points Won')
plt.show()
# extract net points won for early and late rounds
early_rounds = ['Round 1', 'Round 2']
late_rounds = rounds[2:]
net_points_early = df.loc[df['Round'].isin(early_rounds)]['NPW.1']
net_points_late = df.loc[df['Round'].isin(late_rounds)]['NPW.1']
df = df.dropna(subset=['NPW.1', 'NPW.2'])
earlier_rounds = df[df['Round'] <= 3]['NPW.1'] + df[df['Round'] <= 3]['NPW.2']
later_rounds = df[df['Round'] > 3]['NPW.1'] + df[df['Round'] > 3]['NPW.2']
t_statistic, p_value = ttest_ind(earlier_rounds, later_rounds, equal_var=False)
