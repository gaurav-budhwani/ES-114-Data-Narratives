import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

df = pd.read_csv('FrenchOpen-women-2013.csv')
rounds = df['Round'].unique()
avg_fsp_list = []
for r in rounds:
    avg_fsp = df[df['Round'] == r]['FSP.1'].mean()
    avg_fsp_list.append(avg_fsp)
pivot_table = pd.pivot_table(df, values='FSP.1', index='Round', aggfunc='mean')
sns.heatmap(pivot_table, cmap='YlGnBu', annot=True, fmt='.2f')
plt.title('Average Percentage of First Serves In by Round')
plt.xlabel('Round')
plt.ylabel('')
plt.show()
