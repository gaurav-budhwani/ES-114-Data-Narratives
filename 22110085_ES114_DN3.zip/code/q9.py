import pandas as pd

# load data
data = pd.read_csv('Wimbledon-women-2013.csv')
data2 =  pd.read_csv('Wimbledon-men-2013.csv')
data = data.replace('?', np.nan)
data['BP_diff'] = data['BPC.1'] - data['BPW.1']
data2['BP_diff'] = data2['BPC.1'] - data2['BPW.1']
print("For Women")
print(data['BP_diff'].describe())
print("Men")
print(data2['BP_diff'].describe())
sns.histplot(data, x='BP_diff', color='blue', alpha=0.5)
plt.xlabel('Difference in Break Points Created')
plt.ylabel('Frequency')
plt.title('Distribution of BP_diff')
plt.show()
sns.kdeplot(data, x='BP_diff', color='blue', alpha=0.5)
plt.xlabel('Difference in Break Points Created')
plt.ylabel('Density')
plt.title('Density Plot of BP_diff')
plt.show()
sns.histplot(data2, x='BP_diff', color='blue', alpha=0.5)
plt.xlabel('Difference in Break Points Created')
plt.ylabel('Frequency')
plt.title('Distribution of BP_diff')
plt.show()
sns.kdeplot(data2, x='BP_diff', color='blue', alpha=0.5)
plt.xlabel('Difference in Break Points Created')
plt.ylabel('Density')
plt.title('Density Plot of BP_diff')
plt.show()

