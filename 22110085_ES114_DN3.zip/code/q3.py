#question 3
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv('FrenchOpen-men-2013.csv')
sns.scatterplot(data=df, x='DBF.1', y='TPW.1')
plt.xlabel('Double Faults')
plt.ylabel('Total Points Won')
plt.title('2013 Men French Open')
plt.show()
correlation = df['DBF.1'].corr(df['TPW.1'])
print(f'The coorelaion coefficient is {correlation}')
