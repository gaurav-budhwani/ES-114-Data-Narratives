import pandas as pd
import numpy as np
from sklearn.decomposition import PCA
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.preprocessing import OneHotEncoder
from sklearn.impute import SimpleImputer
import matplotlib.pyplot as plt
import seaborn as sns
# load data
df = pd.read_csv('USOpen-women-2013.csv')
df = df.replace('?', np.nan)
X = df.drop(['Result'], axis=1)
y = df['Result']
cat_cols = ['Player 1', 'Player 2', 'ROUND']
enc = OneHotEncoder(handle_unknown='ignore')
X_cat = enc.fit_transform(X[cat_cols]).toarray()
cat_feature_names = enc.get_feature_names_out(input_features=cat_cols)
cat_feature_names_flat = [f"{name}" for name in cat_feature_names]
num_cols = list(set(X.columns) - set(cat_cols))
X_num = X[num_cols].values
imp = SimpleImputer(strategy='median')
X_num = imp.fit_transform(X_num)
X = np.concatenate((X_cat, X_num), axis=1)
selector = SelectKBest(score_func=f_classif, k=10)
X = selector.fit_transform(X, y)
pca = PCA(n_components=2)
X = pca.fit_transform(X)
features = cat_feature_names_flat + num_cols
indices = np.argsort(selector.scores_)[::-1][:10]
print("The most important factors that contribute to a player's success are:")
for i in indices:
    print(features[i])
sns.scatterplot(x=X[:, 0], y=X[:, 1], hue=data['ROUND'])
plt.xlabel('Principal Component 1')
plt.ylabel('Principal Component 2')
plt.title('PCA of US Open Women\'s 2013 Tournament')
plt.show()
sns.barplot(x=['PC%d' % i for i in range(1, len(pca.explained_variance_ratio_)+1)], 
            y=pca.explained_variance_ratio_)
plt.xlabel('Principal Component')
plt.ylabel('Explained Variance Ratio')
plt.title('PCA Component Importance in US Open Women\'s 2013 Tournament')
plt.show()

