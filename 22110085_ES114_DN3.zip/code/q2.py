#question 2 
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import ttest_ind


data = pd.read_csv("AusOpen-women-2013.csv")
plt.figure(figsize=(8, 6))
sns.boxplot(x='Round', y='UFE.1', data=data)
plt.title("Number of unforced errors in different rounds")
plt.xlabel("Round")
plt.ylabel("Number of unforced errors by Player1")
plt.show()
data = data.dropna(subset = ['Round', 'UFE.1'])
round1_ufe = data[data['Round'] == 1]['UFE.1']
round2_ufe = data[data['Round'] == 2]['UFE.1']
round3_ufe = data[data['Round'] == 3]['UFE.1']
round4_ufe = data[data['Round'] == 4]['UFE.1']
qf_ufe = data[data['Round'] == 5]['UFE.1']
sf_ufe = data[data['Round'] == 6]['UFE.1']
f_ufe = data[data['Round'] == 7]['UFE.1']
t, p = ttest_ind(round1_ufe, round2_ufe)
print("t-value for Round 1 vs Round 2:", t)
print("p-value for Round 1 vs Round 2:", p)
t, p = ttest_ind(round2_ufe, round3_ufe)
print("t-value for Round 2 vs Round 3:", t)
print("p-value for Round 2 vs Round 3:", p)
t, p = ttest_ind(round3_ufe, round4_ufe)
print("t-value for Round 3 vs Round 4:", t)
print("p-value for Round 3 vs Round 4:", p)
t, p = ttest_ind(round4_ufe, qf_ufe)
print("t-value for Round 4 vs Quarterfinals:", t)
print("p-value for Round 4 vs Quarterfinals:", p)
t, p = ttest_ind(qf_ufe, sf_ufe)
print("t-value for Quarterfinals vs Semifinals:", t)
print("p-value for Quarterfinals vs Semifinals:", p)
t, p = ttest_ind(sf_ufe, f_ufe)
print("t-value for Semifinals vs Final:", t)
print("p-value for Semifinals vs Final:", p)
plt.figure(figsize=(8, 6))
sns.scatterplot(x='UFE.1', y='Result', data=data)
plt.title("Relationship between number of unforced errors and match result")
plt.xlabel("Number of unforced errors by Player1")
plt.ylabel("Result (W or L)")
plt.show()