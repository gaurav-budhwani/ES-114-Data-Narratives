import pandas as pd
import scipy.stats as stats
import seaborn as sns
import matplotlib.pyplot as plt

df = pd.read_csv('USOpen-women-2013.csv')
df = df.replace('?', np.nan)
X = df['WNR.1']
Y = df['WNR.2']
# mean and standard deviation of X and Y
mu_X = X.mean()
mu_Y = Y.mean()
sigma_X = X.std()
sigma_Y = Y.std()
# mean and standard deviation of Z = X - Y
mu_Z = mu_X - mu_Y
sigma_Z = np.sqrt(sigma_X**2 + sigma_Y**2)
prob = 1 - stats.norm.cdf(0, mu_Z, sigma_Z)
print(f"The probability that Player1 will hit more winners than Player2 in a given match is {prob:.4f}")
print(f"The probability that Player1 will hit more winners than Player2 in a given match is {prob:.4f}")
sns.histplot(data, x='WNR.1', color='blue', alpha=0.5, label='Player 1')
sns.histplot(data, x='WNR.2', color='red', alpha=0.5, label='Player 2')
plt.xlabel('Number of Winners')
plt.ylabel('Frequency')
plt.title('Distribution of Winners Hit by Player 1 and Player 2')
plt.legend()
plt.show()
sns.kdeplot(data, x='WNR.1', color='blue', alpha=0.5, label='Player 1')
sns.kdeplot(data, x='WNR.2', color='red', alpha=0.5, label='Player 2')
plt.xlabel('Number of Winners')
plt.ylabel('Density')
plt.title('Density Plot of Winners Hit by Player 1 and Player 2')
plt.legend()
plt.show()
