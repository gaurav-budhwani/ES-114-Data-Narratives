import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import seaborn as sns

data = pd.read_csv('USOpen-men-2013.csv')
data['FiveSets'] = data['FNL1'] + data['FNL2'] == 5
features = ['ACE.1', 'BPW.1', 'ACE.2', 'BPW.2']
X_train, X_test, y_train, y_test = train_test_split(data[features], data['FiveSets'], 
                                                    test_size=0.2, random_state=42)
model = LogisticRegression()
model.fit(X_train, y_train)
accuracy = model.score(X_test, y_test)
print('Accuracy:', accuracy)
for feature in features:
    plt.figure()
    sns.histplot(data=data, x=feature, hue='FiveSets', kde=True)
    plt.title(feature)
plt.figure()
sns.scatterplot(data=data, x='ACE.1', y='ACE.2', hue='FiveSets')
plt.xlabel('Player 1 Aces')
plt.ylabel('Player 2 Aces')
plt.title('Number of Aces Served by Player 1 and Player 2')
plt.show()
