import pandas as pd
from scipy.stats import poisson

df = pd.read_csv("Wimbledon-men-2013.csv")
df = df.loc[df["ACE.1"] == 1]
k = np.arange(0, 15)
prob_aces = poisson.pmf(k=k, mu=3.5)
mean_aces = df["ACE.1"].mean()
fig, ax = plt.subplots(figsize=(8, 6))
ax.bar(k, prob_aces, color='lightblue')
ax.set_xticks(k)
ax.set_xlabel("Number of aces served by Player1")
ax.set_ylabel("Probability")
ax.set_title("Poisson distribution of aces served by Player1")
plt.plot(k, prob_aces, "bo-", ms=8, label="Poisson Distribution")
plt.legend(loc="best")
plt.show()
prob_5_aces = poisson.pmf(k=5, mu=mean_aces)
print(f"The mean number of aces served by Player1 is {mean_aces:.2f}")
print(f"The probability of Player1 serving exactly 5 aces in a given match is {prob_5_aces:.4f}")
