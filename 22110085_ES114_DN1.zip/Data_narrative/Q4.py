import pandas as pd
import matplotlib.pyplot as plt
# reading the dataset and dropping the repeating rows
df = pd.read_csv('books.csv').drop_duplicates()
total_books = len(df)
recent_books = df[df['original_publication_year'] >= df['original_publication_year'].max() - 5]
year_counts = recent_books['original_publication_year'].value_counts().sort_index()
prob_last_n_years = year_counts.sum() / books.shape[0]
num_recent_books = len(recent_books)
prob_recent_book = num_recent_books / total_books
print(f"The probability of a book being selected randomly being 5 years old is :{prob_recent_book}")
fig, ax = plt.subplots()
ax.bar(year_counts.index, year_counts.values)
ax.set_xlabel('Year')
ax.set_ylabel('Number of Books Published')
ax.set_title('Books Published in last 5 Years')
ax.text(2015.5, max(year_counts.values)*0.8, f'Probability : {prob_last_n_years}')
plt.show()
