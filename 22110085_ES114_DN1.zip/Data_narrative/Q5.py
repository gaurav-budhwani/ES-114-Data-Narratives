import pandas as pd
import matplotlib.pyplot as plt
# reading the dataset and dropping the repeating rows
df = pd.read_csv('books.csv').drop_duplicates()
# calculate the mean rating for all books
mean_rating = df['average_rating'].mean()
# creating a column for rating deviation from the mean
df['rating_deviation'] = df['average_rating'] - mean_rating
# calculating the probability of a book having a rating deviation of more than 0.5
num_books = len(df)
num_high_deviation_books = len(df[df['rating_deviation'].abs() > 0.5])
probability = num_high_deviation_books / num_books
print('Probability of a book having a rating deviation of more than 0.5:', probability)
# plotting the probability distribution of rating deviations
plt.hist(df['rating_deviation'], bins=20)
plt.axvline(x=0.5, color='r', linestyle='--')
plt.axvline(x=-0.5, color='r', linestyle='--')
plt.title('Probability distribution of rating deviations')
plt.xlabel('Rating deviation from mean')
plt.ylabel('Number of books')
plt.show()
