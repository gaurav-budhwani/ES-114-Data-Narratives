import pandas as pd
import matplotlib.pyplot as plt
# loading the CSV data into a Pandas dataframe
df = pd.read_csv('books.csv')
# group books by year and count the number of books published each year
book_counts_by_year = df.groupby(df['original_publication_year'].dt.year).size()
# plot a line chart showing the number of books published each year
plt.plot(book_counts_by_year.index, book_counts_by_year.values)
plt.xlabel('Year')
plt.ylabel('Number of Books Published')
plt.title('Book Publication Over Time')
plt.show()
