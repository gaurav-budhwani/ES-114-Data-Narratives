import pandas as pd
import matplotlib.pyplot as plt
# loading the data
df = pd.read_csv('books.csv')
# group by author and compute the average rating and number of books published
author_stats = df.groupby('authors').agg({'average_rating': 'mean','book_id': 'count'})
author_stats = author_stats.reset_index()
# create the scatter plot
fig, ax = plt.subplots()
ax.scatter(author_stats['book_id'], author_stats['average_rating'], alpha=0.5)
ax.set_xlabel('Number of books published by author')
ax.set_ylabel('Average rating')
ax.set_title('Number of books published vs average rating by author')
plt.show()