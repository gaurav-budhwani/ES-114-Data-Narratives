import pandas as pd
import matplotlib.pyplot as plt
df = pd.read_csv('books.csv')
# calculating the mean rating for each author
author_mean_ratings = df.groupby('authors')['average_rating'].mean()
# calculating the rating deviation for each book
df['Rating Deviation'] = abs(df['average_rating'] - df['authors'].map(author_mean_ratings))
# removing any rows with missing values
df.dropna(inplace=True)
# creating a subset of the data for books with high average ratings
high_rating_books = df[df['average_rating'] > df['average_rating'].median()]
# creating a subset of the data for books with low average ratings
low_rating_books = df[df['average_rating'] <= df['average_rating'].median()]
# plotting the distribution of rating deviation for each subset
plt.hist(high_rating_books['Rating Deviation'], alpha=0.5, label='High Rating Books')
plt.hist(low_rating_books['Rating Deviation'], alpha=0.5, label='Low Rating Books')
plt.xlabel('Rating Deviation')
plt.ylabel('Frequency')
plt.legend(loc='upper right')
plt.show()
