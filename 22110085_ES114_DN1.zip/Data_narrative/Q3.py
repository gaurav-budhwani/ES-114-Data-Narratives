import pandas as pd
import matplotlib.pyplot as plt
# loading the data
df = pd.read_csv('books.csv')
author_counts = df['authors'].value_counts()
# plotting a horizontal bar chart of the most prolific authors
plt.barh(author_counts.index[:10], author_counts.values[:10])
plt.xlabel('Number of Books Published')
plt.ylabel('Author')
plt.title('Most Prolific Authors')
plt.show()