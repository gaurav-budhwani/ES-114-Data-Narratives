import pandas as pd
import matplotlib.pyplot as plt
# load the dataset
df = pd.read_csv('books.csv')
# finding the median number of ratings
median_ratings = df['ratings_count'].median()
# finding the median average rating
median_avg_rating = df['average_rating'].median()
# creating a new column for rating deviation
df['rating_deviation'] = abs(df['average_rating'] - median_avg_rating)
# finding the proportion of books with high number of ratings
high_ratings = df[df['ratings_count'] > median_ratings]
# finding the proportion of books with high average rating
high_avg_ratings = high_ratings[high_ratings['average_rating'] > median_avg_rating]
# finding the proportion of books with high number of ratings and high average rating
high_ratings_and_avg = len(high_avg_ratings) / len(high_ratings)
print("Probability of a book with a high number of ratings also having a high average rating:", round(high_ratings_and_avg, 2))
# creating a scatter plot of number of ratings vs average rating
plt.scatter(df['ratings_count'], df['average_rating'], alpha=0.2)
# adding vertical line for median number of ratings
plt.axvline(x=median_ratings, color='red', linestyle='--', label='Median Number of Ratings')
# adding horizontal line for median average rating
plt.axhline(y=median_avg_rating, color='green', linestyle='--', label='Median Average Rating')
# adding legend and labels
plt.legend()
plt.xlabel('Number of Ratings')
plt.ylabel('Average Rating')
plt.title('Relationship between Number of Ratings and Average Rating')
# show plot
plt.show()
