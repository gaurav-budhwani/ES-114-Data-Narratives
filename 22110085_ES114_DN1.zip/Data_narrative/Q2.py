import pandas as pd
import matplotlib.pyplot as plt
# load the dataset
df = pd.read_csv("books.csv")
# calculating the Number of Ratings
df['num_ratings'] = (df['ratings_1'] + df['ratings_2'] + df['ratings_3'] + df['ratings_4'] + df['ratings_5'])
# plot the relationship between average rating and number of ratings
plt.scatter(df['average_rating'], df['num_ratings'])
plt.xlabel('Average Rating')
plt.ylabel('Number of Ratings')
plt.title('Relationship between Average Rating and Number of Ratings', fontsize = 9)
plt.show()
