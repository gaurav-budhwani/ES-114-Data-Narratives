import pandas as pd
import matplotlib.pyplot as plt
df = pd.read_csv('books.csv')
# calculating median of average ratings
median_rating = df['average_rating'].median()
# creating a list of unique authors
unique_authors = df['authors'].unique()
# counting the number of authors with at least one book in the dataset
total_authors = len(unique_authors)
# counting the number of authors with at least one book above the median rating
high_rating_authors = len(df[df['average_rating'] > median_rating]['authors'].unique())
# calculating the probability
probability = high_rating_authors / total_authors
print("The probability of a randomly selected author having published a book with a high average rating is: {:.2f}%".format(probability*100))
# calculating the probability of an author having a high average rating
high_avg = df[df['average_rating'] > df['average_rating'].median()]
high_avg_authors = high_avg.groupby('authors').size().reset_index(name='count')
total_authors = df['authors'].nunique()
prob = len(high_avg_authors) / total_authors
# creating a pie chart to visualize the probability
labels = ['High Avg Rating Authors', 'Other Authors']
sizes = [len(high_avg_authors), total_authors - len(high_avg_authors)]
colors = ['lightblue', 'pink']
explode = (0.1, 0)
plt.pie(sizes, explode=explode, labels=labels, colors=colors, autopct='%1.1f%%', startangle=90)
plt.axis('equal')
plt.title('Probability of an author having a high average rating')
plt.show()
