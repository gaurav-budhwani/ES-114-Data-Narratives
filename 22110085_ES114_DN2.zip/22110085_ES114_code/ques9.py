import pandas as pd
import scipy.stats as stats
import matplotlib.pyplot as plt

data = pd.read_csv('aaup.csv')



fig, ax = plt.subplots(nrows=1, ncols=2, figsize=(10, 5))
data.plot.scatter(x='FICE', y='Avg salary - all ranks', ax=ax[0])
ax[0].set_xlabel('FICE')
ax[0].set_ylabel('Average Salary')
data.plot.scatter(x='FICE', y='Avg compensation - all ranks', ax=ax[1])
ax[1].set_xlabel('FICE')
ax[1].set_ylabel('Average Compensation')
plt.show()
slope, intercept, r_value, p_value, std_err = stats.linregress(data['FICE'], data['Avg salary - all ranks'])
print("Linear regression results for salary:")
print("Slope:", slope)
print("Intercept:", intercept)
print("R value:", r_value)
print("P value:", p_value)
print("Standard error", std_err)
