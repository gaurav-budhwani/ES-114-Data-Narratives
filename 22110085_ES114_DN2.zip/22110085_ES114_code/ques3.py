import pandas as pd
import seaborn as sns

df = pd.read_csv('usnews.csv')

fac_term_deg = df['Pct. of faculty with terminal degree']
grad_rate = df['Graduation rate']
corr = fac_term_deg.corr(grad_rate)
print('Correlation coefficient:', corr)
sns.regplot(x=fac_term_deg, y=grad_rate, color='purple', line_kws={'color':'lawngreen'})
plt.title('Faculty with Terminal Degrees vs. Graduation Rates')
plt.xlabel('Percentage of Faculty with Terminal Degree')
plt.ylabel('Graduation Rate')
plt.show()
