from scipy.stats import f_oneway

state_groups = []
for state in data['State'].unique():
    state_groups.append(data[data['State'] == state]['Avg compensation - all ranks'])
f_stat, p_value = f_oneway(*state_groups)
print("One-way ANOVA results for compensation of professors:")
print("F-statistic:", f_stat)
print("P-value:", p_value)
fig, ax = plt.subplots(figsize=(18, 5))
data.boxplot(column='Avg compensation - all ranks', by='State', ax=ax)
ax.set_title('')
ax.set_xlabel('State')
ax.set_ylabel('Average Compensation')
plt.show()