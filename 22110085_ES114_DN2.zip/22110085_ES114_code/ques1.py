import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df = pd.read_csv("usnews.csv")

# calculating the correlation between SAT scores and graduation rate
corr_math = np.corrcoef(data['Avg Math SAT score'], data['Graduation rate'])[0, 1]
corr_verbal = np.corrcoef(data['Avg Verbal SAT score'], data['Graduation rate'])[0, 1]
plt.scatter(df["Avg Math SAT score"], df["Graduation rate"])
plt.xlabel("Avg Math SAT score")
plt.ylabel("Graduation rate")
plt.title("Math SAT score vs Graduation rate")
plt.scatter(df["Avg Verbal SAT score"], df["Graduation rate"])
plt.xlabel("Avg Verbal SAT score")
plt.ylabel("Graduation rate")
plt.title("Verbal and Math SAT score vs Graduation rate")
plt.legend(["Math SAT","Verbal SAT"])
plt.show()
print(f"Correlation between math SAT score and graduation rate: {corr_math}")
print(f"Correlation between verbal SAT score and graduation rate: {corr_verbal}")