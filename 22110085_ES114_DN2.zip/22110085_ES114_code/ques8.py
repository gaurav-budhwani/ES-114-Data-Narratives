import pandas as pd
import scipy.stats as stats
import matplotlib.pyplot as plt

df = pd.read_csv('aaup.csv')

fig, ax = plt.subplots(nrows=1, ncols=2, figsize=(26, 5))
df.boxplot(column='Avg salary - all ranks', by='State', ax=ax[0], rot=90)
ax[0].set_title('Salary by State')
df.boxplot(column='Avg compensation - all ranks', by='State', ax=ax[1], rot=90)
ax[1].set_title('Compensation by State')
plt.tight_layout()
plt.show()
salary_anova = stats.f_oneway(*(group['Avg salary - all ranks'] for name, group in df.groupby('State')))
print("ANOVA test results for salary:\n", salary_anova)
compensation_anova = stats.f_oneway(*(group['Avg compensation - all ranks'] for name, group in df.groupby('State')))
print("\nANOVA test results for compensation:\n", compensation_anova)
