
from scipy.stats import ttest_ind
data = pandas.read_csv("aaup.csv")
california_data = data[data['State'] == 'CA']
new_york_data = data[data['State'] == 'NY']
california_compensation = california_data['Avg compensation - all ranks']
new_york_compensation = new_york_data['Avg compensation - all ranks']
t_stat, p_value = ttest_ind(california_compensation, new_york_compensation)
print("T-test results for average compensation of all ranks:")
print("T-statistic:", t_stat)
print("P-value:", p_value)
fig, ax = plt.subplots()
california_compensation.plot(kind='density', ax=ax, label='California')
new_york_compensation.plot(kind='density', ax=ax, label='New York')
ax.set_xlabel('Average Compensation')
ax.set_ylabel('Density')
plt.legend()
plt.show()
