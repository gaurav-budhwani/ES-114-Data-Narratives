import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import scipy.stats as stats

df = pd.read_csv('usnews.csv')

tx_sat = df.loc[df['State'] == 'TX', 'Avg Combined SAT score']
mu = np.mean(tx_sat)
sigma = np.std(tx_sat)
plt.hist(tx_sat, density=True, alpha=0.5, bins=15)
x_vals = np.linspace(mu - 3*sigma, mu + 3*sigma, 100)
plt.plot(x_vals, stats.norm.pdf(x_vals, mu, sigma))
plt.title('Distribution of SAT Scores of Students Accepted in Texas Colleges')
plt.xlabel('SAT Scores')
plt.ylabel('Probability Density')
plt.show()
