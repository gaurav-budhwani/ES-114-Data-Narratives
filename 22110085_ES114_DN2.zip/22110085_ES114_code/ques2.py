import pandas as pd
import matplotlib.pyplot as plt

college_data = pd.read_csv('usnews.csv')

public_colleges = college_data[college_data['Public/private'] == 1]
private_colleges = college_data[college_data['Public/private'] == 2]
avg_public_tuition = public_colleges[['In-state tuition', 'Out-of-state tuition', 'Additional fees']].mean().sum()
avg_private_tuition = private_colleges[['In-state tuition', 'Out-of-state tuition', 'Additional fees']].mean().sum()
print('Average tuition and fees for public colleges: ${:,.2f}'.format(avg_public_tuition))
print('Average tuition and fees for private colleges: ${:,.2f}'.format(avg_private_tuition))
avg_top10_public = public_colleges['Pct. new students from top 10% of H.S. class'].mean().sum()
avg_top10_private = private_colleges['Pct. new students from top 10% of H.S. class'].mean().sum()
print('Average percentage of top 10% students enrolling in public colleges: {:.2f}%'.format(avg_top10_public))
print('Average percentage of top 10% students enrolling in private colleges: {:.2f}%'.format(avg_top10_private))
fig, ax = plt.subplots()
tuition_data = [avg_public_tuition, avg_private_tuition]
college_types = ['Public', 'Private']
ax.bar(college_types, tuition_data)
ax.set_title('Average Tuition and Fees by College Type')
ax.set_ylabel('Tuition and Fees ($)')
ax.set_ylim(0, 35000)
plt.show()
plt.scatter(college_data["In-state tuition"] + college_data["Additional fees"], college_data["Pct. new students from top 10% of H.S. class"])
plt.xlabel("Tuition fees")
plt.ylabel("% of students from top 10%")
plt.title("Tuition fees vs % of students from top 10%")
plt.show()



