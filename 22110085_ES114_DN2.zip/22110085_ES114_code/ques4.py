import pandas as pd
import matplotlib.pyplot as plt
df = pd.read_csv('usnews.csv')

df = df.dropna(subset=['Avg ACT score'])
state_scores = df.groupby('State')['Avg ACT score'].mean().sort_values()
plt.figure(figsize=(10,6))
plt.bar(state_scores.index, state_scores.values)
plt.xticks(rotation=90)
plt.title('Average ACT Score by State')
plt.xlabel('State')
plt.ylabel('Average ACT Score')
plt.show()
