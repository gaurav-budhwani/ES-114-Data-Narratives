from scipy.stats import norm

instructors = data['Number of instructors']

fig, ax = plt.subplots(figsize=(10, 5))
ax.hist(instructors, density=True, bins=20, alpha=0.5, label='Histogram')
xmin, xmax = ax.get_xlim()
x = np.linspace(xmin, xmax, 100)
mean, std = norm.fit(instructors)
pdf = norm.pdf(x, mean, std)
ax.plot(x, pdf, label='Normal Density')
ax.set_xlabel('Number of Instructors')
ax.set_ylabel('Density')
plt.legend()
plt.show()
print("Mean:", mean)
print("Standard Deviation:", std)

