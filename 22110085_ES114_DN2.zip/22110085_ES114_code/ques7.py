import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv('usnews.csv')

sat_scores = df.groupby('State')['Avg Combined SAT score'].median()
acceptance_rates = df.groupby('State')['Number of applicants accepted', 'Number of applications received'].sum()
acceptance_rates['Acceptance Rate'] = acceptance_rates['Number of applicants accepted'] / acceptance_rates['Number of applications received']
plt.scatter(sat_scores, acceptance_rates['Acceptance Rate'])
plt.title('Correlation Between Acceptance Rate and Median SAT Score by State')
plt.xlabel('Median SAT Score')
plt.ylabel('Acceptance Rate')
plt.show()
