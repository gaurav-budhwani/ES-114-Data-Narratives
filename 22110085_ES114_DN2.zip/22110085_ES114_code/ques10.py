
from scipy.stats import probplot
data = pandas.read_csv('aaup.csv')
fig, ax = plt.subplots()
probplot(data['Avg compensation - all ranks'], plot=ax)
plt.show()