import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv('usnews.csv')


df = df.dropna(subset=['In-state tuition'])
plt.figure(figsize=(10,6))
sns.histplot(df['In-state tuition'], kde=True, stat='density')
plt.title('Probability Distribution of In-State Tuition')
plt.xlabel('In-State Tuition')
plt.ylabel('Density')
plt.show()
