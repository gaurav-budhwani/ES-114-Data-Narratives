from statsmodels.stats.multicomp import MultiComparison

mc = MultiComparison(data['Avg compensation - all ranks'], data['Type'])
result = mc.tukeyhsd(alpha=0.05)
print(result)